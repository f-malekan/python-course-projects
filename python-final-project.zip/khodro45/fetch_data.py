import mysql.connector
import urllib3
import json


mydb = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="root",
    database="malekzade_test"
)

print("Connect to database successfully.")

pages = int(input("How many pages do you want to scrap? "))

for page in range(1, pages+1):
    http = urllib3.PoolManager()
    response = http.request(
        'GET', "https://khodro45.com/api/v2/car_listing/?page={}&ordering=-created_time".format(page))

    data = json.loads(response.data)

    if 'results' not in data:
        print("Scrape page {} failed".format(page))
        print(data)

        continue

    print("Scrape page {} successfull".format(page))

    cursor = mydb.cursor()
    for item in data['results']:
        cursor.execute("INSERT INTO `cars` (`slug`, `brand`, `model`, `year`, `city`, `price`) VALUES ('{}', '{}', '{}', {}, '{}',{});"
                       .format(item['slug'],
                               item['car_properties']['brand']['title_en'],
                               item['car_properties']['model']['title_en'],
                               item['car_properties']['year'],
                               item['city']['title_en'],
                               item['price'])
                       )

    mydb.commit()
