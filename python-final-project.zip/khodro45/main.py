import mysql.connector
from Car import Car

brand = input("Enter you brand: ")
model = input("Enter you model: ")

mydb = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="root",
    database="malekzade_test"
)

print("Connect to database successfully.")

cursor = mydb.cursor()

cursor.execute(
    "SELECT * FROM `cars` WHERE brand='{}' AND model='{}'".format(brand, model))

results = cursor.fetchall()

stats = {}
for item in results:
    car = Car(*item)

    if car.year not in stats:
        stats[car.year] = {}
        stats[car.year]['total'] = car.price
        stats[car.year]['count'] = 1
    else:
        stats[car.year]['total'] += car.price
        stats[car.year]['count'] += 1

for item in stats:
    print("Year:{} , Count:{}, Total:{}, Average:{} ".format(
        item, stats[item]['count'], stats[item]['total'], round(stats[item]['total'] / stats[item]['count'])))
