class Car:

    def __init__(self, id, slug, brand, model, year, city, price):
        self.id = id
        self.slug = slug
        self.brand = brand
        self.model = model
        self.year = year
        self.city = city
        self.price = price
